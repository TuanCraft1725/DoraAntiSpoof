package vn.dora.antispoof;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;
import vn.dora.antispoof.command.AdminCommand;
import vn.dora.antispoof.listener.ChannelListener;
import vn.dora.antispoof.manager.DetectionManager;
import vn.dora.antispoof.util.Lang;

import java.util.Objects;

public final class DoraAntiSpoof extends JavaPlugin implements PluginMessageListener {
    private Lang lang;
    private DetectionManager detectionManager;
    private ChannelListener channelListener;

    @Override
    public void onEnable() {
        if (Bukkit.getPluginManager().getPlugin("packetevents") == null
                || !Bukkit.getPluginManager().isPluginEnabled("packetevents")) {
            getLogger().severe("PacketEvents is required. Install it before DoraAntiSpoof.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        saveDefaultConfig();
        saveResourceIfMissing("vi.lang");
        saveResourceIfMissing("en.lang");
        loadLanguage();

        this.detectionManager = new DetectionManager(this);
        this.channelListener = new ChannelListener(this);

        // Client brand is carried as a plugin message. PacketEvents is a required
        // protocol dependency; Bukkit's stable plugin-message API handles decoding.
        getServer().getMessenger().registerIncomingPluginChannel(this, "minecraft:brand", this);
        getServer().getPluginManager().registerEvents(channelListener, this);

        Objects.requireNonNull(getCommand("doraantispoof")).setExecutor(new AdminCommand(this));
        getLogger().info(Lang.color(lang.get("plugin-enabled").replace("{version}", getDescription().getVersion())));
    }

    @Override
    public void onDisable() {
        if (getServer().getMessenger() != null) {
            getServer().getMessenger().unregisterIncomingPluginChannel(this);
        }
        getLogger().info("DoraAntiSpoof disabled.");
    }

    @Override
    public void onPluginMessageReceived(String channel, org.bukkit.entity.Player player, byte[] message) {
        if (!"minecraft:brand".equals(channel)) return;
        String brand = BrandDecoder.decode(message);
        detectionManager.handleBrand(player, brand);
    }

    public void reloadDora() {
        reloadConfig();
        loadLanguage();
    }

    private void loadLanguage() {
        String language = getConfig().getString("settings.language", "vi");
        String file = language.equalsIgnoreCase("en") ? "en.lang" : "vi.lang";
        this.lang = new Lang(this, file);
    }

    private void saveResourceIfMissing(String name) {
        if (!getDataFolder().toPath().resolve(name).toFile().exists()) saveResource(name, false);
    }

    public Lang lang() { return lang; }
    public DetectionManager detection() { return detectionManager; }
}
