package vn.dora.antispoof.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRegisterChannelEvent;
import org.bukkit.event.player.PlayerUnregisterChannelEvent;
import vn.dora.antispoof.DoraAntiSpoof;

public final class ChannelListener implements Listener {
    private final DoraAntiSpoof plugin;

    public ChannelListener(DoraAntiSpoof plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onRegister(PlayerRegisterChannelEvent event) {
        plugin.detection().handleChannel(event.getPlayer(), event.getChannel());
    }

    @EventHandler
    public void onUnregister(PlayerUnregisterChannelEvent event) {
        // Unregistering channels is normal client behavior; intentionally not flagged.
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.detection().remove(event.getPlayer());
    }
}
