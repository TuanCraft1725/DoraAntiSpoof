package vn.dora.antispoof.util;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import vn.dora.antispoof.DoraAntiSpoof;

import java.io.File;
import java.util.Map;

public final class Lang {
    private final YamlConfiguration messages;

    public Lang(DoraAntiSpoof plugin, String fileName) {
        File file = new File(plugin.getDataFolder(), fileName);
        this.messages = YamlConfiguration.loadConfiguration(file);
    }

    public String get(String key) {
        return messages.getString(key, key);
    }

    public String format(String key, Map<String, String> values) {
        String result = get(key);
        for (Map.Entry<String, String> entry : values.entrySet()) {
            result = result.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return color(result);
    }

    public static String color(String input) {
        return ChatColor.translateAlternateColorCodes('&', input == null ? "" : input);
    }

    public static String stripColors(String input) {
        return ChatColor.stripColor(color(input));
    }
}
