package vn.dora.antispoof.util;

import java.nio.charset.StandardCharsets;

public final class BrandDecoder {
    private BrandDecoder() {}

    public static String decode(byte[] payload) {
        if (payload == null || payload.length == 0) return "";
        try {
            int[] cursor = {0};
            int length = readVarInt(payload, cursor);
            if (length < 0 || length > payload.length - cursor[0]) {
                // Some non-standard clients send plain UTF-8 instead of a VarInt string.
                return new String(payload, StandardCharsets.UTF_8).trim();
            }
            return new String(payload, cursor[0], length, StandardCharsets.UTF_8).trim();
        } catch (RuntimeException ex) {
            return new String(payload, StandardCharsets.UTF_8).trim();
        }
    }

    private static int readVarInt(byte[] data, int[] cursor) {
        int value = 0;
        int position = 0;
        byte current;
        do {
            if (cursor[0] >= data.length || position >= 35) throw new IllegalArgumentException("Invalid VarInt");
            current = data[cursor[0]++];
            value |= (current & 0x7F) << position;
            position += 7;
        } while ((current & 0x80) != 0);
        return value;
    }
}
