package vn.dora.antispoof.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import vn.dora.antispoof.DoraAntiSpoof;
import vn.dora.antispoof.util.Lang;

public final class AdminCommand implements CommandExecutor {
    private final DoraAntiSpoof plugin;

    public AdminCommand(DoraAntiSpoof plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("doraantispoof.admin")) {
            sender.sendMessage(Lang.color(plugin.lang().get("no-permission")));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadDora();
            sender.sendMessage(Lang.color(plugin.lang().get("reloaded")));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("info")) {
            sender.sendMessage(plugin.lang().format("info", java.util.Map.of(
                    "version", plugin.getDescription().getVersion(),
                    "language", plugin.getConfig().getString("settings.language", "vi"))));
            return true;
        }
        sender.sendMessage(Lang.color(plugin.lang().get("usage")));
        return true;
    }
}
