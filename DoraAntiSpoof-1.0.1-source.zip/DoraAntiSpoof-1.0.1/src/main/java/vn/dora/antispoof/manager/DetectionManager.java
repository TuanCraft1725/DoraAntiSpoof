package vn.dora.antispoof.manager;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import vn.dora.antispoof.DoraAntiSpoof;
import vn.dora.antispoof.util.Lang;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public final class DetectionManager {
    private final DoraAntiSpoof plugin;
    private final Map<UUID, Integer> violations = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastViolation = new ConcurrentHashMap<>();
    private final Set<UUID> receivedBrand = ConcurrentHashMap.newKeySet();
    private final Set<UUID> missingBrandChecked = ConcurrentHashMap.newKeySet();

    public DetectionManager(DoraAntiSpoof plugin) {
        this.plugin = plugin;
        long delay = Math.max(20L, plugin.getConfig().getLong("checks.missing-brand.delay-ticks", 100));
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!plugin.getConfig().getBoolean("checks.missing-brand.enabled", true)
                    || !plugin.getConfig().getBoolean("checks.missing-brand.flag", false)) return;
            for (Player player : Bukkit.getOnlinePlayers()) {
                UUID id = player.getUniqueId();
                if (missingBrandChecked.add(id) && !receivedBrand.contains(id) && !isBedrock(player)) {
                    flag(player, "MISSING_BRAND", plugin.lang().get("missing-brand"));
                }
            }
        }, delay, delay);
    }

    public void handleBrand(Player player, String brand) {
        if (player == null || !player.isOnline()) return;
        receivedBrand.add(player.getUniqueId());

        if (isBedrockBrand(brand) && plugin.getConfig().getBoolean("geyser.enabled", true)
                && plugin.getConfig().getBoolean("geyser.exempt-bedrock", true)) return;

        if (!plugin.getConfig().getBoolean("checks.brand.enabled", true)) return;
        if ((brand == null || brand.isBlank()) && plugin.getConfig().getBoolean("checks.brand.detect-empty", true)) {
            flag(player, "EMPTY_BRAND", plugin.lang().get("brand-empty"));
            return;
        }

        int max = plugin.getConfig().getInt("checks.brand.max-length", 64);
        if (plugin.getConfig().getBoolean("checks.brand.detect-oversized", true) && brand.length() > max) {
            flag(player, "LONG_BRAND", plugin.lang().get("brand-long"));
            return;
        }

        for (String regex : plugin.getConfig().getStringList("checks.brand.suspicious-patterns")) {
            if (matches(regex, brand)) {
                flag(player, "SUSPICIOUS_BRAND",
                        plugin.lang().get("brand-pattern").replace("{brand}", safe(brand)));
                break;
            }
        }
    }

    public void handleChannel(Player player, String channel) {
        if (!plugin.getConfig().getBoolean("checks.channels.enabled", true) || channel == null) return;
        if (channel.length() > plugin.getConfig().getInt("checks.channels.max-channel-length", 128)) {
            flag(player, "CHANNEL_LENGTH", "Channel name exceeds configured limit");
            return;
        }
        for (String ignored : plugin.getConfig().getStringList("checks.channels.ignored")) {
            if (ignored.equalsIgnoreCase(channel)) return;
        }
        for (String regex : plugin.getConfig().getStringList("checks.channels.blocked-patterns")) {
            if (matches(regex, channel)) {
                flag(player, "SUSPICIOUS_CHANNEL",
                        plugin.lang().get("channel-pattern").replace("{channel}", safe(channel)));
                return;
            }
        }
    }

    public void remove(Player player) {
        UUID id = player.getUniqueId();
        receivedBrand.remove(id);
        missingBrandChecked.remove(id);
        violations.remove(id);
        lastViolation.remove(id);
    }

    private boolean isBedrock(Player player) {
        String brand = player.getName(); // Do not infer Bedrock solely from a username.
        return false;
    }

    private boolean isBedrockBrand(String brand) {
        if (!plugin.getConfig().getBoolean("geyser.enabled", true) || brand == null) return false;
        for (String regex : plugin.getConfig().getStringList("geyser.known-brand-patterns")) {
            if (matches(regex, brand)) return true;
        }
        return false;
    }

    private void flag(Player player, String check, String detail) {
        long now = System.currentTimeMillis();
        long resetMs = Math.max(1, plugin.getConfig().getLong("violations.reset-after-minutes", 10)) * 60_000L;
        Long last = lastViolation.get(player.getUniqueId());
        if (last != null && now - last > resetMs) violations.remove(player.getUniqueId());
        lastViolation.put(player.getUniqueId(), now);
        int vl = violations.merge(player.getUniqueId(), 1, Integer::sum);

        String alert = plugin.lang().format("alert", Map.of(
                "player", player.getName(), "check", check, "detail", safe(detail), "violations", String.valueOf(vl)));
        if (plugin.getConfig().getBoolean("alerts.console", true)) plugin.getLogger().warning(Lang.stripColors(alert));
        if (plugin.getConfig().getBoolean("alerts.admins", true)) {
            Bukkit.getOnlinePlayers().stream().filter(p -> p.hasPermission("doraantispoof.alerts"))
                    .forEach(p -> p.sendMessage(alert));
        }

        int threshold = plugin.getConfig().getInt("violations.max-before-kick", 5);
        String mode = plugin.getConfig().getString("punishment.mode", "ALERT");
        if ("KICK".equalsIgnoreCase(mode) && vl >= threshold) {
            player.kickPlayer(Lang.color(plugin.getConfig().getString("punishment.kick-message",
                    "&cDisconnected by DoraAntiSpoof")));
        }
    }

    private boolean matches(String regex, String input) {
        try { return Pattern.compile(regex).matcher(input).matches(); }
        catch (RuntimeException ex) {
            plugin.getLogger().warning("Invalid regex in config.yml: " + regex);
            return false;
        }
    }

    private String safe(String value) {
        if (value == null) return "null";
        return value.length() > 100 ? value.substring(0, 100) : value;
    }
}
